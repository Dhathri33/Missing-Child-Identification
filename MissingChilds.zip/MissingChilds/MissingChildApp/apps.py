from django.apps import AppConfig


class MissingchildappConfig(AppConfig):
    name = 'MissingChildApp'
